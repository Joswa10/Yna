# Spring Snow ♡

A tiny interactive gift site. Plain HTML/CSS/JS — no build step.

```
Yna/
├── index.html        page structure
├── styles.css        all styling and animation
├── script.js         intro, audio sync, lyrics, hearts, snow, cursor
├── lyrics.js         ★ song file path, start/end times, lyrics + timestamps
├── .nojekyll         tells GitHub Pages to serve files as-is
└── assets/
    ├── background.jpg      included
    └── spring-snow.mp3     ★ you add this
```

## 1. Add the song
Copy your audio file into `assets/` and name it `spring-snow.mp3`
(or edit `audioSrc` in `lyrics.js`). Use a file you have the right to use.
Without it, the site runs in silent preview mode.

## 2. Set exact lyric timings
The timestamps in `lyrics.js` are even estimates. To fix them:
1. Run the site locally with `?sync` on the end of the URL: `http://localhost:8000/?sync`
2. Open the surprise, press play, and press **M** the moment each line begins.
3. Copy the generated list from the panel into the `lyrics` array in `lyrics.js`.

## 3. Test locally
```
cd Yna
python3 -m http.server 8000
```
Open http://localhost:8000. (Use a local server, not a double-clicked file, so audio seeking works.)

## 4. Publish on GitHub Pages
1. Open https://github.com/Joswa10/Yna → **Add file → Upload files**.
2. Drag in everything inside the project folder (including the `assets` folder and `.nojekyll`), then **Commit changes**.
3. Go to **Settings → Pages**. Under *Build and deployment*, choose **Deploy from a branch**, branch **main**, folder **/ (root)**, then **Save**.
4. Wait 1–2 minutes. Your link: **https://joswa10.github.io/Yna/**

## 5. Check it works
Open the link in a private window and on your phone. Confirm: the intro plays, the button opens the lyrics,
audio starts at 0:20, lyrics follow the song, it stops at 2:15, and "Listen again" restarts it.
If the audio is silent, check the filename/case in `assets/` (GitHub is case-sensitive).
